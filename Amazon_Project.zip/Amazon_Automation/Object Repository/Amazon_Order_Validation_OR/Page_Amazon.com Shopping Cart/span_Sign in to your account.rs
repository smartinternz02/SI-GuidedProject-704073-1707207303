<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Sign in to your account</name>
   <tag></tag>
   <elementGuidId>5e3c7e47-0ecf-4d08-aee2-99046a38623d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='a-autoid-0-announce']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-size-base-plus</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Sign in to your account&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fa0899b7-f721-4b88-8efa-82f84ee4e3d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-base-plus</value>
      <webElementGuid>2a689230-f853-41c1-a873-b992904bfb72</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Sign in to your account
                </value>
      <webElementGuid>e7129aa8-0631-4b2f-9afe-3e249f476f02</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-autoid-0-announce&quot;)/span[@class=&quot;a-size-base-plus&quot;]</value>
      <webElementGuid>ceccec10-1796-4b63-91a0-5d38efad516b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='a-autoid-0-announce']/span</value>
      <webElementGuid>90ce61cd-71f1-4a6f-af41-88980164862a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your Amazon Cart is empty'])[1]/following::span[3]</value>
      <webElementGuid>1fad0c88-2ca6-4318-95c5-9bf3b62c2da4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up now'])[1]/preceding::span[1]</value>
      <webElementGuid>ac9e3262-1cbf-48f0-b97c-9d140c13198b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No items saved for later'])[1]/preceding::span[4]</value>
      <webElementGuid>3a15ea4e-8294-44b0-a4c7-0fcb8c30fafe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign in to your account']/parent::*</value>
      <webElementGuid>d14e9321-0d37-4641-9a50-c864c264839f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span/a/span</value>
      <webElementGuid>7b5b9eb3-d7cd-4024-9ef6-8a454a54bd30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                    Sign in to your account
                ' or . = '
                    Sign in to your account
                ')]</value>
      <webElementGuid>7933b0d4-9bab-4d3f-b3d7-ab1e6ac3323b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
