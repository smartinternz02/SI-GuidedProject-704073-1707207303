<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Amazon Privacy Policy_burger-menu</name>
   <tag></tag>
   <elementGuidId>695138f2-10a0-4112-bdc7-5d617120bbe4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Amazon Privacy Policy'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>svg.burger-menu</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>af094b88-7a60-4025-a16d-0f6171f11658</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>burger-menu</value>
      <webElementGuid>501ddeb7-2fe3-4732-a73f-a16739b5c877</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;Homepage&quot;]/body[@class=&quot;Homepage-body&quot;]/header[@class=&quot;Homepage-header&quot;]/div[@class=&quot;Homepage-header-bottom&quot;]/ps-header[@class=&quot;Page-header&quot;]/div[@class=&quot;Page-header-wrapper&quot;]/div[@class=&quot;Page-header-bar&quot;]/button[@class=&quot;Page-header-menu-trigger&quot;]/svg[@class=&quot;burger-menu&quot;]</value>
      <webElementGuid>585b1dcc-9b0b-417e-bbfa-2e137aa184c2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Amazon Privacy Policy'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>4e3d40a4-1122-48a3-af64-bfc3538373e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Conditions of Use'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>5047131d-d8dc-403e-a1ee-7581589f2b19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Menu'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>874f7d4c-e144-45aa-a4fd-871a2c7466b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submit Search'])[1]/preceding::*[name()='svg'][3]</value>
      <webElementGuid>8f7fc259-cf85-4cb4-81fe-ed0350dd7af3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
