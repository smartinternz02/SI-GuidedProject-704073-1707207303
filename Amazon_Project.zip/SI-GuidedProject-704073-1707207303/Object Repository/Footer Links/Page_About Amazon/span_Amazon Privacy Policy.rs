<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Amazon Privacy Policy</name>
   <tag></tag>
   <elementGuidId>b14d3314-4f5a-45b6-96fc-5b5499466434</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Conditions of Use'])[1]/following::span[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2151f34f-2648-4234-b265-7b384a7c95f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Amazon Privacy Policy</value>
      <webElementGuid>6e323933-44b8-4b90-b934-d620d6e77baf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;Homepage&quot;]/body[@class=&quot;Homepage-body&quot;]/header[@class=&quot;Homepage-header&quot;]/div[@class=&quot;Homepage-header-bottom&quot;]/ps-header[@class=&quot;Page-header&quot;]/div[@class=&quot;Page-header-wrapper&quot;]/div[@class=&quot;Page-header-hamburger-menu&quot;]/div[@class=&quot;Page-header-hamburger-menu-wrapper&quot;]/div[@class=&quot;Page-header-hamburger-menu-content&quot;]/div[@class=&quot;Page-header-disclaimer&quot;]/span[@class=&quot;Enhancement-inline&quot;]/span[@class=&quot;Enhancement-item&quot;]/a[@class=&quot;Link&quot;]/span[1]</value>
      <webElementGuid>4d158565-142f-4440-9a02-025254ab346a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Conditions of Use'])[1]/following::span[3]</value>
      <webElementGuid>8c573914-8bef-41c5-bf38-9d816d690828</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Amazon.com'])[1]/following::span[6]</value>
      <webElementGuid>26a60e1b-45ea-49e1-a297-f38134865e4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Menu'])[1]/preceding::span[1]</value>
      <webElementGuid>2a3d7056-0a3f-4520-8e9e-1eab33a881d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submit Search'])[1]/preceding::span[4]</value>
      <webElementGuid>040aee78-8223-447d-8ff6-13f4f0fdc7a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Amazon Privacy Policy']/parent::*</value>
      <webElementGuid>772b9645-e0f6-440f-843a-4933a306eee2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]/span/a/span</value>
      <webElementGuid>c55ab0d6-004a-494f-af93-188e54471dcc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Amazon Privacy Policy' or . = 'Amazon Privacy Policy')]</value>
      <webElementGuid>8c49d35c-f3b2-4de0-b9b7-b40ff2f623e9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
