<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_EN</name>
   <tag></tag>
   <elementGuidId>cab35da8-4c20-4675-ae4b-da6458211e96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='icp-nav-flyout']/span/span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.icp-nav-link-inner > span.nav-line-2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b557c13a-c2a9-4ef9-85b6-a17f6cb8d8e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-line-2</value>
      <webElementGuid>ca9af715-c744-401f-8082-37c93de646d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
          EN
        
      </value>
      <webElementGuid>bf13e45e-40d0-4e92-9096-a5f8ae283932</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-nav-flyout&quot;)/span[@class=&quot;icp-nav-link-inner&quot;]/span[@class=&quot;nav-line-2&quot;]</value>
      <webElementGuid>9867e063-786e-453d-b03e-4bc76c898a31</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='icp-nav-flyout']/span/span[2]</value>
      <webElementGuid>f129d7e0-d5e1-4cae-9428-baf4a516bbe7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search Amazon.ae'])[1]/following::span[4]</value>
      <webElementGuid>235e9197-8127-4b4f-8d39-502b9ada0bff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All'])[1]/following::span[4]</value>
      <webElementGuid>f6841db7-2a05-42a6-8b51-7a2dab3f9169</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hello, sign in'])[1]/preceding::span[3]</value>
      <webElementGuid>4d6227be-20bd-450d-bb5f-7c4feb1dfbc1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span[2]</value>
      <webElementGuid>0b214fb4-dc21-4541-a2d5-54092b1a87c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        
          EN
        
      ' or . = '
        
          EN
        
      ')]</value>
      <webElementGuid>3f37ed5d-39ac-421e-9ad6-e7304f21492a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
