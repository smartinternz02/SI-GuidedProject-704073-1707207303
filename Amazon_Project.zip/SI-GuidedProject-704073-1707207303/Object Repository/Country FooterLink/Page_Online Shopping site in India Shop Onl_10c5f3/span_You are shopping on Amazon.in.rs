<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_You are shopping on Amazon.in</name>
   <tag></tag>
   <elementGuidId>99320107-53d9-408e-a20d-2dd495e16bc0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='nav-flyout-icp']/div[2]/span/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.nav-item > span.nav-text</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f01efccb-9c1a-4030-8d50-f0800998179c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-text</value>
      <webElementGuid>1a7986b3-41cd-469e-8b02-20568dbf80b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>You are shopping on Amazon.in</value>
      <webElementGuid>f18dfc48-8956-4d68-8aac-bb7344b5974f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-flyout-icp&quot;)/div[@class=&quot;nav-template nav-flyout-content nav-tpl-itemList&quot;]/span[@class=&quot;nav-item&quot;]/span[@class=&quot;nav-text&quot;]</value>
      <webElementGuid>4214f209-d22d-447a-9002-4793b849c125</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-flyout-icp']/div[2]/span/span</value>
      <webElementGuid>05d485da-2548-42b0-8d6f-5a5fd630a898</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[1]/following::span[2]</value>
      <webElementGuid>6a40ebb5-ba31-4283-bec8-71258c79109b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MR'])[1]/following::span[3]</value>
      <webElementGuid>01cd76f9-35a5-42fc-b41c-8c684d3fb90b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Change country/region.'])[1]/preceding::span[2]</value>
      <webElementGuid>d1f40409-733d-4972-84de-dbca31f97581</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='You are shopping on']/parent::*</value>
      <webElementGuid>6dced345-ae51-458c-9fec-ad11fd0bed39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[13]/div[2]/span/span</value>
      <webElementGuid>45f59969-10e4-4751-883e-b5d76f095216</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'You are shopping on Amazon.in' or . = 'You are shopping on Amazon.in')]</value>
      <webElementGuid>1eeb2751-a128-4ac5-aced-f193e85dc398</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
