<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_1-16 of over 7,000 results for laptop</name>
   <tag></tag>
   <elementGuidId>abf4f3e4-9af3-4a5b-9070-d9813e3fece5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='search']/span[2]/div/h1/div/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-section.a-spacing-small.a-spacing-top-small</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0f20e27f-239b-4e69-bd99-781bbfee2e12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-section a-spacing-small a-spacing-top-small</value>
      <webElementGuid>76a63498-0485-431b-a686-369c3947b079</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                1-16 of over 7,000 results for &quot;laptop&quot;
            </value>
      <webElementGuid>5008f112-0aef-47e7-9e26-e578f3b5a50c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;search&quot;)/span[@class=&quot;rush-component&quot;]/div[@class=&quot;s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=UPPER template=RESULT_INFO_BAR widgetId=result-info-bar&quot;]/h1[@class=&quot;a-size-base s-desktop-toolbar a-text-normal&quot;]/div[@class=&quot;s-desktop-width-max sg-row-align-items-center s-wide-grid-style sg-row&quot;]/div[@class=&quot;sg-col-14-of-20 sg-col-18-of-24 sg-col s-breadcrumb sg-col-10-of-16 sg-col-6-of-12&quot;]/div[@class=&quot;sg-col-inner&quot;]/div[@class=&quot;a-section a-spacing-small a-spacing-top-small&quot;]</value>
      <webElementGuid>5d4f5ef0-1775-41f8-b67a-6c57ed437688</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='search']/span[2]/div/h1/div/div/div/div</value>
      <webElementGuid>f5eefa87-88b2-4a25-abb7-95da3451bd38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Disability Customer Support'])[1]/following::div[14]</value>
      <webElementGuid>0a78627f-bf50-4db8-bf1b-1f912a953332</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sell'])[1]/following::div[14]</value>
      <webElementGuid>cf010ea3-1a63-4731-8f5e-7f7aa1fb567d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sort by:'])[1]/preceding::div[6]</value>
      <webElementGuid>9f719b3e-6820-4164-a655-e1deb2cde01b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1/div/div/div/div</value>
      <webElementGuid>30d3cf14-0ce1-4014-aeec-5afe1632574d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                1-16 of over 7,000 results for &quot;laptop&quot;
            ' or . = '
                1-16 of over 7,000 results for &quot;laptop&quot;
            ')]</value>
      <webElementGuid>d1dada7c-9d78-4964-9d01-a104422a77ee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
